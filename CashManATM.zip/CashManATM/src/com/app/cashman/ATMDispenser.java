package com.app.cashman;

import java.util.List;
import java.util.Scanner;

public class ATMDispenser {

	
	public static void main(String[] args) {
		ReadWriteCSV rwCSV =  new ReadWriteCSV();		
		boolean stop=false;
		ProbabilityCheck probability = new ProbabilityCheck();
		AccountPOJO acc = new AccountPOJO();
		while (true) {
			int amountWithdrawn = 0;
			acc= rwCSV.readCSV(acc);
			acc.setBalance(acc.getArrList().get(0));
			acc.setDenom50(acc.getArrList().get(1));
			acc.setDenom20(acc.getArrList().get(2));
			System.out.println("Account Balance is " + acc.getBalance() + " and CashMan has "+acc.getDenom20()+ " -20s and " +acc.getDenom50()+" -50s ");
			System.out.println("Please Enter Withdraw Amount");
			Scanner input = new Scanner(System.in);
			acc.setAmountWithdrawn(input.nextInt());
			if(amountWithdrawn <= acc.getBalance()){
				acc.setBalance(acc.getBalance()-acc.getAmountWithdrawn());
				List<Integer[]> results =probability.getProbability(acc);
				if(results.isEmpty()){
					System.out.println("Please check the balance and Enter Denomination of 20s and 50s only");
				}else{
					if(acc.getBalance() <= 500){
						System.out.println("Account reached Threshold limit and your balance is "+ acc.getBalance());
					}
				 for (Integer[] result : results){
			            Integer[] denominations = result;
						  if(denominations[0] <= acc.getDenom20() && denominations[1] <= acc.getDenom50())
						  {
							  acc.setWdDenom20(denominations[0]);
							  acc.setWdDenom50(denominations[1]);
							  acc.setDenom50(acc.getDenom50()-acc.getWdDenom50());
							  acc.setDenom20(acc.getDenom20()-acc.getWdDenom20());
							  stop= rwCSV.writeCSV(acc);
							   if(stop){
								   System.out.println("You have withdrawn "+acc.getAmountWithdrawn()+" and your balance is " +acc.getBalance());
								   System.out.println("Denominations of 20s="+ denominations[0] +" and 50s= " +denominations[1] +"has been withdrawn");
								   break;
							   }
						  	}else{
								System.out.println("Cash Man has "+acc.getDenom20()+" - 20s only and " +acc.getDenom50()+ " - 50s only.");
							}
				 }
				}
			}else{
				System.out.println("Insufficient Amount. Balance left with " +acc.getBalance());
			}
		}

}
}