package com.app.cashman;

import java.util.ArrayList;
import java.util.List;

public class ProbabilityCheck {
    int[] values = {20,50};

    public List<Integer[]> getProbability(AccountPOJO acc) {
        int[] values = {20,50};
        int denom20 = acc.getDenom20();
        int denom50 = acc.getDenom50();
        int[] ammounts = {denom20,denom50};
        List<Integer[]> results = solutions(values, ammounts, new int[2],acc.getAmountWithdrawn(), 0);       
        return results;
    }

    private List<Integer[]> solutions(int[] values, int[] ammounts, int[] variation, int price, int position){
        List<Integer[]> list = new ArrayList<>();
        int value = compute(values, variation);
        if (value < price){
            for (int i = position; i < values.length; i++) {
                if (ammounts[i] > variation[i]){
                    int[] newvariation = variation.clone();
                    newvariation[i]++;
                    List<Integer[]> newList = solutions(values, ammounts, newvariation, price, i);
                    if (newList != null){
                        list.addAll(newList);
                    }
                }
            }
        } else if (value == price) {
            list.add(myCopy(variation));
        }
        return list;
    }    

    private int compute(int[] values, int[] variation){
        int ret = 0;
        for (int i = 0; i < variation.length; i++) {
            ret += values[i] * variation[i];
        }
        return ret;
    }    

    private Integer[] myCopy(int[] ar){
        Integer[] ret = new Integer[ar.length];
        for (int i = 0; i < ar.length; i++) {
            ret[i] = ar[i];
        }
        return ret;
    }
}