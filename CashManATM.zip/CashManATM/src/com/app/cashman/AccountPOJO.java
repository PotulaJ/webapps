package com.app.cashman;

import java.util.ArrayList;

public class AccountPOJO {
	
	private int balance;
	private int denom50;
	private int denom20;
	private int amountWithdrawn =0;
	private int wdDenom50 =0;
	private int wdDenom20 =0;
	ArrayList<Integer> arrList= new ArrayList<Integer>();
	
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getAmountWithdrawn() {
		return amountWithdrawn;
	}
	public void setAmountWithdrawn(int amountWithdrawn) {
		this.amountWithdrawn = amountWithdrawn;
	}
	public int getDenom50() {
		return denom50;
	}
	public void setDenom50(int denom50) {
		this.denom50 = denom50;
	}
	public int getDenom20() {
		return denom20;
	}
	public void setDenom20(int denom20) {
		this.denom20 = denom20;
	}
	
	public int getWdDenom50() {
		return wdDenom50;
	}
	public void setWdDenom50(int wdDenom50) {
		this.wdDenom50 = wdDenom50;
	}
	public int getWdDenom20() {
		return wdDenom20;
	}
	public void setWdDenom20(int wdDenom20) {
		this.wdDenom20 = wdDenom20;
	}
	public ArrayList<Integer> getArrList() {
		return arrList;
	}
	public void setArrList(ArrayList<Integer> arrList) {
		this.arrList = arrList;
	}
	
	public void setProperties(ArrayList<Integer> arrList) {
		this.arrList = arrList;
	}

	
}
