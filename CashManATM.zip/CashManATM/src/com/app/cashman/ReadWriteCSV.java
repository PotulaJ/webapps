package com.app.cashman;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class ReadWriteCSV {
	
	// reads the csv file to get the amounts to process the request
	
	public AccountPOJO readCSV(AccountPOJO acc) {
		String csvFile = "src/CashManATM.csv";
		ArrayList<Integer> arrList = new ArrayList<Integer>();
		List<String[]> inList = new ArrayList<String[]>();
		try (CSVReader reader = new CSVReader(new FileReader(csvFile), ',', '\'', 1)) {
			String[] nextLine;
			while ((nextLine = reader.readNext()) != null) {
				inList.add(nextLine);
			}
			nextLine = inList.get(inList.size() - 1);
			for (String value : nextLine) {
				arrList.add(Integer.parseInt(value));
			}
			acc.setArrList(arrList);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return acc;
	}

	// write transaction details to csv

	public boolean writeCSV(AccountPOJO acc) {
		String csv = "src/CashManATM.csv";
		try (CSVWriter writer = new CSVWriter(new FileWriter(csv, true), ',', CSVWriter.NO_QUOTE_CHARACTER)) {
			String[] row = new String[6];
			row[0] = Integer.toString(acc.getBalance());
			row[1] = Integer.toString(acc.getDenom50());
			row[2] = Integer.toString(acc.getDenom20());
			row[3] = Integer.toString(acc.getAmountWithdrawn());
			row[4] = Integer.toString(acc.getWdDenom50());
			row[5] = Integer.toString(acc.getWdDenom20());
			writer.writeNext(row);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

}